import requests

# Azure Document Intelligence Config
DOC_INTELLIGENCE_ENDPOINT = "https://AutoGraderDocIntelligence .cognitiveservices.azure.com/"
DOC_INTELLIGENCE_KEY = "16ab66ba74d04f0bb49b63f7219bcd78"

def extract_text_from_doc(file_path):
    """Extracts structured text from Word or Excel using Azure Document Intelligence."""
    with open(file_path, "rb") as file_data:
        file_content = file_data.read()

    headers = {
        "Ocp-Apim-Subscription-Key": DOC_INTELLIGENCE_KEY,
        "Content-Type": "application/octet-stream"
    }

    response = requests.post(
        f"{DOC_INTELLIGENCE_ENDPOINT}/formrecognizer/documentModels/prebuilt-layout:analyze?api-version=2023-07-01-preview",
        headers=headers,
        data=file_content
    )

    result = response.json()

    # Extract text from the analyzed result
    extracted_text = "\n".join([line["content"] for page in result.get("pages", []) for line in page.get("lines", [])])
    return extracted_text

# Example Usage
word_text = extract_text_from_doc("CS581 Assignment 2 HIS Clinical (EHR) Functional Requirements Grading Rubric -2025 Spring 1.docx")
excel_text = extract_text_from_doc("Assignment Template - EHR_System_Functional_Evaluation_Worksheet.xlsx")

print("Extracted Word Content:\n", word_text)
print("Extracted Excel Content:\n", excel_text)
